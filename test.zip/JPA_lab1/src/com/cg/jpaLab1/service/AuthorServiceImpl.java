package com.cg.jpaLab1.service;

import com.cg.jpaLab1.dao.AuthorDao;
import com.cg.jpaLab1.dao.AuthorDaoImpl;
import com.cg.jpaLab1.entities.Author;

public class AuthorServiceImpl implements AuthorService{
	
	private AuthorDao dao;
	
	public AuthorServiceImpl() {
		dao = new AuthorDaoImpl();
	}
	@Override
	public void addAuthor(Author author) {
		// TODO Auto-generated method stub
		dao.beginTransaction();
		dao.addAuthor(author);
		dao.commitTransaction();		
	}

	@Override
	public void updateAuthor(Author author) {
		// TODO Auto-generated method stub
		dao.beginTransaction();
		dao.updateAuthor(author);
		dao.commitTransaction();
	}

	@Override
	public void removeAuthor(Author author) {
		// TODO Auto-generated method stub
		dao.beginTransaction();
		dao.removeAuthor(author);
		dao.commitTransaction();
	}

	@Override
	public Author findAuthorById(int id) {
		// TODO Auto-generated method stub
		Author author = dao.getAuthorById(id);
		return author;
	}
	
	

}
