package com.cg.jpaLab1.client;

import com.cg.jpaLab1.entities.Author;
import com.cg.jpaLab1.service.AuthorService;
import com.cg.jpaLab1.service.AuthorServiceImpl;

public class Client {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		AuthorService service = new AuthorServiceImpl();
		Author author = new Author();
		author.setAuthorId(101);
		author.setFirstName("Tanu");
		author.setMiddleName("Sri");
		author.setLastName("Gandaboyina");
		author.setPhoneNo(70365);
		service.addAuthor(author);
		
		
		author = service.findAuthorById(101);
		
		System.out.println("ID:"+author.getAuthorId());
		System.out.println(" Name:"+author.getFirstName()+author.getMiddleName()+author.getLastName());
		
//		author.setAuthorId(102);
		author.setFirstName("Anu");
		author.setMiddleName("Sha");
		author.setLastName("Gandaboyina");
		author.setPhoneNo(98487);
		service.updateAuthor(author);
		
		author = service.findAuthorById(101);
		
		System.out.println("ID:"+author.getAuthorId());
		System.out.println(" Name:"+author.getFirstName()+author.getMiddleName()+author.getLastName());

		
		  
		System.out.println("End of program...");
	}

}
