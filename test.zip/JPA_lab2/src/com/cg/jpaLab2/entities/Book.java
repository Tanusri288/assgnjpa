package com.cg.jpaLab2.entities;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

@Entity
@Table(name="books_master")
public class Book implements Serializable{
	
	private static final long serialVersionUID = 1L;
	@Id
	@Column(name = "ISBN")
	private int ISBN;
	private String title;
	private int price;
	
	@ManyToMany(fetch=FetchType.LAZY,mappedBy="books")
	private Set<Book> books = new HashSet<>();

	public int getISBN() {
		return ISBN;
	}

	public void setISBN(int iSBN) {
		ISBN = iSBN;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	public Set<Book> getBooks() {
		return books;
	}

	public void setBooks(Set<Book> books) {
		this.books = books;
	}
	

}
